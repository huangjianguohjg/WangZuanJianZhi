#import "UIColor+AppTheme.h"
@implementation  UIColor (AppTheme)
+ (UIColor *)appThemeMainBackGroupColor
{
    return [UIColor colorWithHexRGB:0xf6f6fa];
}

- (void)sp_getLoginState {
    NSLog(@"Get User Succrss");
}
@end
