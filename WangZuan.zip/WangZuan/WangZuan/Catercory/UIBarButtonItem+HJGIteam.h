#import <UIKit/UIKit.h>
@interface UIBarButtonItem (HJGIteam)
+ (instancetype)itemWithNorImage:(NSString *)image frame:(CGRect)frame highImage:(NSString *)highImage target:(id)target action:(SEL)action;

- (void)sp_getUsersMostFollowerSuccess;
@end
