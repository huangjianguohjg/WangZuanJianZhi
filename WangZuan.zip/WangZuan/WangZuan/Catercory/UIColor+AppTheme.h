#import <UIKit/UIKit.h>
@interface UIColor (AppTheme)
+ (UIColor *)appThemeMainBackGroupColor;

- (void)sp_getLoginState;
@end
