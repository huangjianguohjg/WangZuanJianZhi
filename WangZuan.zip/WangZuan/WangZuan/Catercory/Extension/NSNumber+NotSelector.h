#import <Foundation/Foundation.h>
@interface NSNumber(NotSelector)

- (void)sp_didUserInfoFailed;
@end
