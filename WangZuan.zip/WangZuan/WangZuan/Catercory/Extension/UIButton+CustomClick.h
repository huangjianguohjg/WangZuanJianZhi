#import <UIKit/UIKit.h>
@interface UIButton (CustomClick)
@property (nonatomic, assign) NSTimeInterval custom_acceptEventInterval;

- (void)sp_getLoginState;
@end
