#import <Foundation/Foundation.h>
@interface NSNull(InternalNullExtention)

- (void)sp_didUserInfoFailed;
@end
