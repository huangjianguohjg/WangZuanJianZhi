#import <Foundation/Foundation.h>
@interface NSArray (Addition)
- (id)safeObjectAtIndex:(NSUInteger)index;

- (void)sp_getMediaData;
@end
