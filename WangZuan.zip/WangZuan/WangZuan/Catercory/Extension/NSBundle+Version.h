#import <Foundation/Foundation.h>
@interface NSBundle (Version)
+ (NSString*)releaseVersion;
+(NSString*)buildVersion;

- (void)sp_getUsersMostFollowerSuccess;
@end
