#import <UIKit/UIKit.h>
@interface UILabel(Extension)
-(CGSize)lblContentSize:(CGSize)size;

- (void)sp_getLoginState;
@end
