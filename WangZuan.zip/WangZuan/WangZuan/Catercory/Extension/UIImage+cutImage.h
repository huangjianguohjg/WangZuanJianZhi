#import <UIKit/UIKit.h>
@interface UIImage (cutImage)
+ (UIImage *)imageWithColor:(UIColor *)color redius:(CGFloat)redius size:(CGSize)size;
+ (UIImage *)imagewithImage:(UIImage *)image;

- (void)sp_getUsersMostLiked;
@end
