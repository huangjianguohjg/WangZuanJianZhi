#import <Foundation/Foundation.h>
@interface NSDictionary (Log)

- (void)sp_checkUserInfo;
@end
