#import <Foundation/Foundation.h>
@interface NSMutableSet(Addition)
- (void)addSafeObject:(id)object;

- (void)sp_didGetInfoSuccess;
@end
