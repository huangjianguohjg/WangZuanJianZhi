#import <Foundation/Foundation.h>
@interface UIColor(Hex)
+ (UIColor *)colorWithHex:(long)hexColor;
+ (UIColor *)colorWithHex:(long)hexColor alpha:(float)opacity;
- (void)sp_checkUserInfo;
@end
