#import <Foundation/Foundation.h>
@interface NSDictionary (HJGDictionary)
- (NSArray *)nk_ascendingComparedAllKeys;
- (NSArray *)nk_descendingComparedAllKeys;

- (void)sp_getUserFollowSuccess;
@end
