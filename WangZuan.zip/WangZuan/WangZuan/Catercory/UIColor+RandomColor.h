#import <UIKit/UIKit.h>
@interface UIColor (RandomColor)
+ (UIColor *)randomColor;

- (void)sp_getMediaData;
@end
