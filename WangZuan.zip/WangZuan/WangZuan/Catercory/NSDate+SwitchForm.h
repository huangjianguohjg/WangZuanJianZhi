#import <Foundation/Foundation.h>
@interface NSDate (SwitchForm)
+ (NSDate *)getDateFromString:(NSString *)date_string;

- (void)sp_didUserInfoFailed;
@end
