#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface UITableView (RegisterCell)
- (void)registerClass:(Class)aclass;

- (void)sp_getUsersMostLikedSuccess;
@end
