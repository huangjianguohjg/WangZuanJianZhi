#import <UIKit/UIKit.h>
@interface UILabel (adjustsFontSizeToFitWidth)
- (NSInteger)getFontSize;

- (void)sp_upload;
@end
