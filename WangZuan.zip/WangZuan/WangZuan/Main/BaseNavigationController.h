#import <UIKit/UIKit.h>
@interface BaseNavigationController : UINavigationController

- (void)sp_getUsersMostLiked;
@end
