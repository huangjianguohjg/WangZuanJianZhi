#import <UIKit/UIKit.h>
@interface HJGBaseView : UIView

- (void)sp_getUserName;
@end
