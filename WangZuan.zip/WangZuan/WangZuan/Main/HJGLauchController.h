#import <UIKit/UIKit.h>
@interface HJGLauchController : UIViewController

- (void)sp_checkUserInfo;
@end
