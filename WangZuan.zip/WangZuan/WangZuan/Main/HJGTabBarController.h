#import <UIKit/UIKit.h>
@interface HJGTabBarController : UITabBarController

- (void)sp_getMediaFailed;
@end
