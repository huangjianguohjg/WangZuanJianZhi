#import <UIKit/UIKit.h>
@interface HJGNavgationController : UINavigationController

- (void)sp_checkUserInfo;
@end
