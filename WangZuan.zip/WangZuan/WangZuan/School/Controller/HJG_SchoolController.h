//
//  HJG_SchoolController.h
//  WangZuan
//
//  Created by Developer on 2018/9/10.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseController.h"

@interface HJG_SchoolController : HJGBaseController

@end
