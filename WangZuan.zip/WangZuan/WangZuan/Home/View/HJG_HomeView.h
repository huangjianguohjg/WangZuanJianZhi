//
//  HJG_HomeView.h
//  WangZuan
//
//  Created by Developer on 2018/9/10.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseView.h"
#import <SDCycleScrollView.h>
@interface HJG_HomeView : HJGBaseView

@property (nonatomic, strong) SDCycleScrollView *cycleView;

@property (nonatomic, strong) NSMutableArray *modelArr;

@end
