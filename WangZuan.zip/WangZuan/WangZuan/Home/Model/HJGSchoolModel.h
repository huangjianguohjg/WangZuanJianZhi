//
//  HJGSchoolModel.h
//  WangZuan
//
//  Created by Developer on 2018/9/10.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseDataModel.h"

@interface HJGSchoolModel : HJGBaseDataModel

@property (nonatomic, strong) NSString *content;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *icon;

@end
