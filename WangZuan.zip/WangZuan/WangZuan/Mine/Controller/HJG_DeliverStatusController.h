//
//  HJG_DeliverStatusController.h
//  WangZuan
//
//  Created by Developer on 2018/9/11.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseController.h"

@interface HJG_DeliverStatusController : HJGBaseController

@end
