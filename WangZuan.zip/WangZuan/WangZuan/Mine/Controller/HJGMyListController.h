//
//  HJGMyListController.h
//  WangZuan
//
//  Created by Developer on 2018/9/12.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseController.h"

@interface HJGMyListController : HJGBaseController

@end
