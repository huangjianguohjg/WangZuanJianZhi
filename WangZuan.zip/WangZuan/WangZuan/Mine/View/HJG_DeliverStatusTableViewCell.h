//
//  HJG_DeliverStatusTableViewCell.h
//  WangZuan
//
//  Created by Developer on 2018/9/12.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJG_HomeTableViewCell.h"

@interface HJG_DeliverStatusTableViewCell : HJG_HomeTableViewCell

@end
