//
//  HJG_JieDanTableViewCell.h
//  WangZuan
//
//  Created by Developer on 2018/9/12.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJG_HomeTableViewCell.h"

@interface HJG_JieDanTableViewCell : HJG_HomeTableViewCell

@property (nonatomic, strong) UIButton *wanchengBut;

@end
