//
//  HJGDeliverBottomTableViewCell.h
//  WangZuan
//
//  Created by Developer on 2018/9/12.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseTableViewCell.h"

@interface HJGDeliverBottomTableViewCell : HJGBaseTableViewCell

@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UITextField *textF;

@property (nonatomic, weak) UIButton *deliverBut;

@end
