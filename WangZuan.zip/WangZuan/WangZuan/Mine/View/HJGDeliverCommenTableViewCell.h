//
//  HJGDeliverCommenTableViewCell.h
//  WangZuan
//
//  Created by Developer on 2018/9/12.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseTableViewCell.h"

@interface HJGDeliverCommenTableViewCell : HJGBaseTableViewCell

@property (nonatomic, weak) UIImageView *iconView;


@property (nonatomic, weak) UITextField *textF;

@end
