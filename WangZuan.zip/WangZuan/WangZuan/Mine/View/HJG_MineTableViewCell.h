//
//  HJG_MineTableViewCell.h
//  WangZuan
//
//  Created by Developer on 2018/9/11.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseTableViewCell.h"

@interface HJG_MineTableViewCell : HJGBaseTableViewCell

@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UILabel *titleLab;

@end
