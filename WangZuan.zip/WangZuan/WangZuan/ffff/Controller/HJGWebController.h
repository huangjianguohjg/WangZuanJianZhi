#import <UIKit/UIKit.h>
@interface HJGWebController : UIViewController
@property (nonatomic, strong) NSString *url_string;

- (void)sp_upload:(NSString *)string;
@end
